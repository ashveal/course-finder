# csvjson.js

csvjson.js is a simple standalone JavaScript file to convert between CSV data
and JSON objects. It is released under the MIT License and fits under 1kb when
minified (even less when gzipped).

At the moment it doesn't have any support for parsing JSON strings, only JSON
style objects (you'll need to use JSON.js to work around that).

The demo website shows how to use it.

Author: Aaron Snoswell (@aaronsnoswell, elucidatedbiany.com)
